 <?php
 
$con = new mysqli('localhost', 'root', '', 'feedback_db');

?>
<style>
	body
	{
		font-family: sans-serif;
		margin: 0px;
		 background-color: #e2e2e2;
	}

 .table 
 {
 	 background-color: #e2e2e2;
 	 border: 6px solid black;
  border-radius: 10px;
  width: 80%;
  height: 400px;
  padding-top: 30px;
  padding-bottom: 20px;
  padding-left: 20px;
  padding-right: 20px;
  
 }
 .table td
 {
 	 border: 1px solid black;
  border-radius: 8px;
  
}
h5
{
	font-size:medium;

}
</style>
<div class="container">
<center>
	<h1 style="padding-top: 10px; color: #FFC107;">STUDENT LIST</h1>
<table class="table table-bordered  table-striped table-sm"   >
	<tr bgcolor="#17eab5">
		<td>
			<center><h5>id</h5></center>
		</td>
		<td>
			<center><h5>students</h5></center>
		</td>
		
		<td>
			<center><h5>coures</h5></center>
		</td>
		<td>
			<center><h5>query</h5></center>
		</td>
		<td>
			<center><h5>submissionDate</h5></center>
		</td>
		

	</tr>
	</center>

<?php
  $sql = "SELECT * FROM teacher ";
   
    $result = $con->query($sql);
while($row=$result->fetch_assoc())
{
?>
	<tr>	
		<td style="width:15%;">
			<center><?= $row["id"] ?></center>
		</td>
		<td>
			<center><?= $row["teacherName"] ?></center>
		</td>
		
		<td>
			<center><?= $row["course"] ?></center>
			
		</td>
		<td>
			<center><?= $row["query"] ?></center>
			
		</td>
		<td>
			<center><?= $row["submissionDate"] ?></center>
			
		</td>
	
		
		
		
	
	
		
	</tr>

<?php
};
?>



</table>
</div>