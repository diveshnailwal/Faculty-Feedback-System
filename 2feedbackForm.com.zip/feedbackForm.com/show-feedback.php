 <?php
session_start();
$error = "";
$con = new mysqli('localhost', 'root', '', 'feedback_db');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $userType = $_POST['userType'];

    // Sanitize user input to prevent SQL injection
    $users = $con->real_escape_string($_POST['username']);
    $password = $con->real_escape_string($_POST['password']);

    $sql = "SELECT * FROM teacherusers WHERE users='$users' AND password='$password'";
    $result = $con->query($sql);

    if ($result) {
        $total_rows = $result->num_rows;

        if ($total_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['users'] = $users;
            $_SESSION['id'] = $row["id"];

             if ($userType == 'teacher') {
                header('location: studentlist.php');
            } else {
                // Add a default redirect or error message if the user type is neither 'student' nor 'teacher'
                header('location:show-feedback.php');
            }

            // Unset and destroy the session
            unset($_SESSION['users']);
            unset($_SESSION['id']);
            session_destroy();
        } else {
            $error = "Login Failed!";
            // Add a script to display a JavaScript alert
            echo '<script>';
            echo 'alert("Incorrect username or password!");';
            echo '</script>';
        }
    } else {
        $error = "Database query error: " . $con->error;
    }
}
?>




<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FEEDBACK FORM</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        .feedBackForm {
            background-color: #e2e2e2;
            height: 100vh;
            width: 100%;
        }
         .back 
        {
           background-image:url(images/bk.png);
          background-repeat:no-repeat ; 
          background-size: cover;
        }
          .border
        {
            box-shadow: -1px 10px 16px 0px rgba(0,0,0,0.63);
           -webkit-box-shadow: -1px 10px 16px 0px rgba(0,0,0,0.63);
          -moz-box-shadow: -1px 10px 16px 0px rgba(0,0,0,0.63);

        }
         .button:hover
        {
         background-color:#2090BF;
         border: solid 1px#2090BF ;
         border-radius: 40px;
         transition: 0.6s;
        }

        h3
        {
          text-shadow: 2px 2px gray; 
        }

    </style>
</head>

<body>
    <div class=" back feedBackForm d-flex justify-content-center align-items-center">
        <div class="container">
            <div class=" border card-body p-md-5 text-black border rounded">
            <div class="row d-flex justify-content-center align-items-center">
                  <div class="col-md-4">

                    <img class="images" src="images/teacher.png" style="float: right;">
                </div>
                <div class="col-md-4">
                    
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                            <div class="formHeading text-warning text-center">
                                <h3 class="mb-5 text-uppercase">FEEDBACK PORTAL</h3>
                            </div>
                            <div class="form-outline mb-4">
                                <input name="username" required type="text" id="form3Example97"
                                    class="form-control form-control-lg" />
                                <label class="form-label" for="form3Example97">Username</label>
                            </div>
                            <div class="form-outline mb-4">
                                <input name="password" required type="text" id="form3Example8"
                                    class="form-control form-control-lg" />
                                <label class="form-label" for="form3Example8">Password</label>
                            </div>
                            <div class="form-outline mb-4">
                                <select id="userType" name="userType" class="form-control form-control-lg">
                                   
                                    <option value="teacher">Teacher</option>
                                </select>
                            </div>
                            <div class="d-flex justify-content-center pt-3">
                                <button type="submit" name="submit" class="btn btn-warning btn-lg ms-2 button">Submit
                                    form</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>


</html>